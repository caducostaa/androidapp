package br.com.bprates.cadastrodeclientes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class ClientesActivity extends AppCompatActivity {

    private TextView tvNome;
    private TextView tvEmail;
    private TextView animais;
    private TextView sexo;
    private ImageView satisfacao;
    private TextView contrato;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clientes);
        Bundle extra = getIntent().getExtras();

        tvNome = findViewById(R.id.tv_nome);
        tvEmail = findViewById(R.id.tv_email);
        animais = findViewById(R.id.tv_animal);
        sexo = findViewById(R.id.tv_sexo);
        satisfacao = findViewById(R.id.iv_satifacao);
        contrato = findViewById(R.id.tv_contrato);


        if (extra != null) {
            Cliente cliente = (Cliente) getIntent().getSerializableExtra("cliente");
            tvNome.setText(cliente.getNome());
            tvEmail.setText(cliente.getEmail());
            String animaisQuePossui = "";
            for (String animal : cliente.getAnimais())
                animaisQuePossui += animal + "\n";

            if (!animaisQuePossui.isEmpty())
                animais.setText(animaisQuePossui);

            sexo.setText(cliente.getSexo());

            if (!cliente.getNivelDeSatisfacao().isEmpty())
                switch (cliente.getNivelDeSatisfacao()) {
                    case "Ruim":
                        satisfacao.setBackgroundColor(getResources().getColor(R.color.ruim));
                        break;
                    case "Regular":
                        satisfacao.setBackgroundColor(getResources().getColor(R.color.regular));
                        break;
                    case "Bom":
                        satisfacao.setBackgroundColor(getResources().getColor(R.color.bom));
                        break;
                    case "Otimo":
                        satisfacao.setBackgroundColor(getResources().getColor(R.color.otimo));
                        break;
                    default:
                        satisfacao.setBackgroundColor(getResources().getColor(R.color.colorAccent));
                }

            if (cliente.isContratoAceito())
                contrato.setText("Aceitou o contrato.");
            

        }
    }
}
