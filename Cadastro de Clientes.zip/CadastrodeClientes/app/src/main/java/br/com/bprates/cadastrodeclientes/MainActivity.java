package br.com.bprates.cadastrodeclientes;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private SeekBar sb;
    private TextView tv_seekbar;
    private AlertDialog.Builder alertaDialog;
    private EditText nome;
    private EditText email;
    private CheckBox cachorro;
    private CheckBox gato;
    private CheckBox papagaio;
    private RadioButton masc;
    private RadioButton femin;
    private String nivelDeSatisfacao = "";
    private Switch contrato;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sb = findViewById(R.id.seekBar);
        tv_seekbar = findViewById(R.id.tv_nivelSatisfacao);

        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (progress <= 3) {
                    nivelDeSatisfacao = "Ruim";
                } else if (progress <= 6) {
                    nivelDeSatisfacao = "Regular";
                } else if (progress <= 8) {
                    nivelDeSatisfacao = "Bom";
                } else {
                    nivelDeSatisfacao = "Otimo";
                }
                tv_seekbar.setText(nivelDeSatisfacao);
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });
    }

    public void salvarCliente(View view) {
        alertaDialog = new AlertDialog.Builder( this );
        alertaDialog.setTitle("Salvar Cliente");
        alertaDialog.setMessage("Você realmente deseja salvar esse cliente?");
        alertaDialog.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                nome = findViewById(R.id.et_nome);
                email = findViewById(R.id.et_email);
                ArrayList<String> animais = new ArrayList();
                cachorro = findViewById(R.id.ck_cachorro);
                gato = findViewById(R.id.ck_gato);
                papagaio = findViewById(R.id.ck_papagaio);

                if (cachorro.isChecked()) {
                    animais.add(cachorro.getText().toString());
                }
                if (gato.isChecked()) {
                    animais.add(gato.getText().toString());
                }
                if (papagaio.isChecked()) {
                    animais.add(papagaio.getText().toString());
                }
                String sexo;
                masc = findViewById(R.id.rb_masculino);
                femin = findViewById(R.id.rb_feminino);

                if (masc.isChecked())
                    sexo = masc.getText().toString();
                else if (femin.isChecked())
                    sexo = femin.getText().toString();
                else
                    sexo = "Não Informado.";

                contrato = findViewById(R.id.sw_contrato);

                Cliente novoCliente = new Cliente(
                        nome.getText().toString(),
                        email.getText().toString(),
                        animais,
                        sexo,
                        nivelDeSatisfacao,
                        contrato.isChecked());

                Intent clienteIntent = new Intent(MainActivity.this,ClientesActivity.class);
                clienteIntent.putExtra("cliente", novoCliente);
                startActivity(clienteIntent);
            }
        });
        alertaDialog.setNegativeButton("Não", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast.makeText(MainActivity.this,"Cliente não salvo", Toast.LENGTH_SHORT).show();
            }
        });

        alertaDialog.create();
        alertaDialog.show();
    }
}
